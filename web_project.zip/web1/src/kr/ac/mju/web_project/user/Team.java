package kr.ac.mju.web_project.user;

import java.util.*;

public class Team implements java.io.Serializable{
	private static final long serialVersionUID = 2193897931951340673L;
	
	private static final String[] TeamName = {"두산", "SK","삼성","한화","롯데","넥센","LG","기아"};

	private String tname;
	public Team(){
	}
	public Team(String tname){
		super();
		this.tname=tname;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	

	

}
