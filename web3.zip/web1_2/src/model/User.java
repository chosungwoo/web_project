package model;

import java.io.Serializable;

public class User implements Serializable {
	
	private String userid;
	private String pwd;
	private String team;
	private String gender;
	
	public User(){
	}
	
	public User(String userid, String pwd, String team, String gender){
		super();
		this.userid = userid;
		this.pwd = pwd;
		this.team = team;
		this.gender = gender;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
}
