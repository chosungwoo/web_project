package model;

import java.sql.*;

import javax.naming.*;
import javax.sql.*;

public class UserDAO {
		public static DataSource getDataSource() throws NamingException{
			Context initCtx = null;
			Context envCtx = null;
			
			//obtain our environment naming context
			initCtx = new InitialContext();
			envCtx = (Context) initCtx.lookup("java:comp/env");
			
			//Look up our data source
			return (DataSource) envCtx.lookup("jdbc/WebDB");
		}
		
		public static PageResult<User> getPage(int page, int numItemsInPage) throws SQLException, NamingException{
			Connection conn = null;
			Statement stmt  = null;
			ResultSet rs = null;
			if(page<=0){
				page = 1;
			}
			DataSource ds = getDataSource();
			PageResult<User> result  = new PageResult<User>(numItemsInPage,page);
			int startPos = (page-1)*numItemsInPage;
			
			try{
				conn = ds.getConnection();
				stmt = conn.createStatement();
				
				//users 테이블 : user 수 페이지수 계산
				rs = stmt.executeQuery("SELECT COUNT(*) FROM ORDER BY name");
				
				while(rs.next()){
					result.getList().add(new User(rs.getString("userid"),
							rs.getString("pwd"),
							rs.getString("team"),
							rs.getString("gender")
							));
				}
			}finally{
				//무슨일이 있어도 리소스를 제대로 종료
				if(rs != null) try{rs.close();} catch(SQLException e){}
				if(stmt != null) try{stmt.close();} catch(SQLException e){}
				if(conn != null) try{conn.close();} catch(SQLException e){}
			}
			return result;
		}
		public static User findById(int id) throws NamingException, SQLException{
			User user = null;
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			
			DataSource ds = getDataSource();
			try{
				conn = ds.getConnection();
				
				//질의 준비
				stmt = conn.prepareStatement("SELECT * FROM users WHERE id = ?");
				stmt.setInt(1, id);
				
				//수행
				rs = stmt.executeQuery();
				
				if(rs.next()){
					user = new User(rs.getString("userid"),
							rs.getString("pwd"),
							rs.getString("team"),
							rs.getString("gender")
							);
				}
			}finally{
				if(rs != null) try{rs.close();} catch(SQLException e){}
				if(stmt != null) try{stmt.close();} catch(SQLException e){}
				if(conn != null) try{conn.close();} catch(SQLException e){}			
			}
			return user;
		}
		public static boolean create(User user) throws SQLException, NamingException{
			int result;
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs  = null;
			
			DataSource ds = getDataSource();
			
			try{
				conn = ds.getConnection();
				
				//질의 준비
				stmt = conn.prepareStatement("INSERT INTO users(userid, pwd, team, gender)" + "VALUES(?,?,?,?)");
				
				stmt.setString(1,user.getUserid());
				stmt.setString(2,user.getPwd());
				stmt.setString(3,user.getTeam());
				stmt.setString(4,user.getGender());
				
				//수행
				result = stmt.executeUpdate();
			}finally{
				if(rs != null) try{rs.close();} catch(SQLException e){}
				if(stmt != null) try{stmt.close();} catch(SQLException e){}
				if(conn != null) try{conn.close();} catch(SQLException e){}			
			}
			return (result==1);
		}
		public static boolean update(User user) throws SQLException, NamingException{
			int result;
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs  = null;
			
			DataSource ds = getDataSource();
			
			try{
				conn = ds.getConnection();
				
				//질의 준비
				stmt = conn.prepareStatement("UPDATE users"+
													"SET userid =?,pwd=?,team=?,gender=?"+
													"WHERE id=?");
				
				stmt.setString(1,user.getUserid());
				stmt.setString(2,user.getPwd());
				stmt.setString(3,user.getTeam());
				stmt.setString(4,user.getGender());
				
				//수행
				result = stmt.executeUpdate();
			}finally{
				if(rs != null) try{rs.close();} catch(SQLException e){}
				if(stmt != null) try{stmt.close();} catch(SQLException e){}
				if(conn != null) try{conn.close();} catch(SQLException e){}			
			}
			return (result==1);
		}
		public static boolean remove(User user) throws SQLException, NamingException{
			int result;
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs  = null;
			
			DataSource ds = getDataSource();
			
			try{
				conn = ds.getConnection();
				
				//질의 준비
				stmt = conn.prepareStatement("DELETE FROM users WHERE id=?");
			//	stmt.setInt(1,id);
				
				//수행
				result = stmt.executeUpdate();
			}finally{
				if(rs != null) try{rs.close();} catch(SQLException e){}
				if(stmt != null) try{stmt.close();} catch(SQLException e){}
				if(conn != null) try{conn.close();} catch(SQLException e){}			
			}
			return (result==1);
		}
}
